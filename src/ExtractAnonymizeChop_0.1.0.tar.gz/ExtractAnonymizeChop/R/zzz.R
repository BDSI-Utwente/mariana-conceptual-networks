anonymize <- NULL
extract <- NULL
complement <- NULL


#' Title
#'
#' @param library
#' @param package
#'
#' @return
#' @export
#' @import reticulate
#'
#' @examples
.onLoad <- function(library, package) {
    reticulate::configure_environment(package)

    anonymize <<- reticulate::import_from_path("anonymize", system.file("python", package = package), delay_load = TRUE )
    extract <<- reticulate::import_from_path("extract", system.file("python", package = package), delay_load = TRUE)
    complement <<- reticulate::import_from_path("complement", system.file("python", package = package), delay_load = TRUE)
}
